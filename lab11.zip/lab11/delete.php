<?php
	header("Content-Type:application/json") ;
	header("Access-Control-Allow-Methods: DELETE") ;
	header("Access-Control-Max-Age: 3600") ;
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With") ;
	

	$data = json_decode(file_get_contents("php://input")) ;

	define ( 'DB_HOST', 'localhost' );
        define ( 'DB_USER', 'regular' );
        define ( 'DB_PASSWORD', 'Passw0rd!' );
        define ( 'DB_NAME', 'employees' );

        $con = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) ;
        if (!$con) {
        	echo mysqli_connect_errno().": ".mysqli_connect_error() ;
                die("<p>The database server is not available.</p>") ;
	}
	
	$emplno = $data ->emplno ;	

	$query = "DELETE FROM employees WHERE emp_no = ".$emplno."";
	echo "<p>".$query."</p>" ;
	$ResultSet = @mysqli_query($con, $query)
		Or die("<p>Unable to execute the update</p>"
		."<p>Error code: ".mysqli_errno($con).": "
				.mysqli_error($con))."</p>" ;
	echo "<p>Successfully Removed".mysqli_affected_rows($con)." record(s).</p>" ;

	// Close the database connection
	mysqli_close($con) ;
	
?>
